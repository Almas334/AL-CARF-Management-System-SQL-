create DATABASE project;
use project;

create table products(
product_id int primary key AUTO_INCREMENT,
product_name varchar(100) UNIQUE not null,
fabric varchar(100),
size enum("small","medium","large"),
pattern enum ("Plain","Printed","Floral","Striped"),
amount decimal (10,2),
color varchar(100),
discount decimal(5,2),
date_time timestamp default CURRENT_TIMESTAMP,
summary text);

INSERT INTO products (product_name, fabric, size, pattern, amount, color, discount, summary)
VALUES
('Silk Floral Scarf', 'Silk', 'Medium', 'Floral', 250.00, 'Pink', 10.00, 'Soft silk scarf with elegant floral patterns'),
('Cotton Plain Hijab', 'Cotton', 'Large', 'Plain', 120.00, 'White', 5.00, 'Lightweight cotton hijab for daily wear'),
('Chiffon Printed Scarf', 'Chiffon', 'Medium', 'Printed', 200.00, 'Blue', 15.00, 'Stylish printed chiffon scarf for casual outings'),
('Georgette Striped Hijab', 'Georgette', 'Medium', 'Striped', 180.00, 'Gray', 8.00, 'Trendy striped hijab with soft texture'),
('Silk Ombre Scarf', 'Silk', 'Medium', 'Plain', 300.00, 'Purple', 12.00, 'Luxury silk scarf with gradient ombre design'),
('Jersey Plain Hijab', 'Jersey', 'Large', 'Plain', 150.00, 'Beige', 5.00, 'Comfortable stretchy hijab for daily wear'),
('Printed Viscose Scarf', 'Viscose', 'Medium', 'Printed', 220.00, 'Green', 10.00, 'Lightweight printed scarf perfect for any outfit'),
('Chiffon Floral Hijab', 'Chiffon', 'Medium', 'Floral', 240.00, 'Red', 12.00, 'Elegant floral hijab suitable for parties'),
('Silk Satin Scarf', 'Silk', 'Small', 'Plain', 280.00, 'Black', 15.00, 'Premium satin scarf with smooth finish'),
('Polyester Striped Scarf', 'Polyester', 'Medium', 'Striped', 170.00, 'Navy Blue', 7.00, 'Affordable polyester scarf with stylish stripes');



create table customers(
customer_id int auto_increment primary key ,
first_name varchar(100) not null,
last_name varchar(100) not null,
phone_no varchar(15) unique,
gmail varchar(50) not null,
date_of_birth date,
city varchar(100),
state varchar(100),
pincode varchar(100),
membership_status enum("Silver","Gold","Platinum"),
last_message TEXT,
address text);

INSERT INTO customers 
(first_name, last_name, phone_no, gmail, gender, date_of_birth, city, state, pincode, membership_status, last_message, address)
VALUES
('Aisha', 'Khan', '9876543210', 'aisha.khan@example.com', 'female', '1995-03-15', 'Karachi', 'Sindh', '74000', 'Silver', NULL, 'Street 12, Clifton'),
('Sara', 'Ali', '9123456780', 'sara.ali@example.com', 'female', '1998-07-21', 'Lahore', 'Punjab', '54000', 'Gold', NULL, 'House 45, Gulberg'),
('Fatima', 'Hussain', '9234567890', 'fatima.hussain@example.com', 'female', '1992-11-02', 'Islamabad', 'Islamabad', '44000', 'Platinum', NULL, 'Street 8, F-7/2'),
('Maryam', 'Raza', '9345678901', 'maryam.raza@example.com', 'female', '2000-01-10', 'Karachi', 'Sindh', '75300', 'Silver', NULL, 'Block 3, DHA'),
('Zainab', 'Shah', '9456789012', 'zainab.shah@example.com', 'female', '1997-05-05', 'Lahore', 'Punjab', '54600', 'Gold', NULL, 'Street 20, Johar Town'),
('Hina', 'Ahmed', '9567890123', 'hina.ahmed@example.com', 'female', '1996-12-18', 'Islamabad', 'Islamabad', '44010', 'Platinum', NULL, 'Street 10, G-10/1'),
('Amna', 'Khalid', '9678901234', 'amna.khalid@example.com', 'female', '1999-08-30', 'Karachi', 'Sindh', '75200', 'Silver', NULL, 'House 25, PECHS'),
('Sana', 'Iqbal', '9789012345', 'sana.iqbal@example.com', 'female', '1994-04-12', 'Lahore', 'Punjab', '54050', 'Gold', NULL, 'Block 6, Model Town'),
('Noor', 'Javed', '9890123456', 'noor.javed@example.com', 'female', '1993-09-22', 'Islamabad', 'Islamabad', '44020', 'Platinum', NULL, 'Street 5, F-8/3'),
('Rabia', 'Saeed', '9901234567', 'rabia.saeed@example.com', 'female', '2001-06-17', 'Karachi', 'Sindh', '75000', 'Silver', NULL, 'Block 2, Korangi');


create table orders(
order_id int auto_increment primary key,
customer_id int,
product_id int,
order_date DATE,
order_time TIME,
delivery_date DATE,
delivery_time TIME,
order_status ENUM('Pending','Processing','Shipped','Out for Delivery','Delivered','Cancelled') DEFAULT 'Pending',
total_amount DECIMAL(10,2),
payment_status ENUM('Pending','Paid','Failed','Refunded') DEFAULT 'Pending',
shipping_address TEXT,
quantity INT DEFAULT 1,
damaged ENUM('Yes','No') DEFAULT 'No',
return_eligible ENUM('Yes','No') DEFAULT 'Yes',
foreign key(customer_id) references customers(customer_id),
foreign key(product_id) references products(product_id));

INSERT INTO orders
(contact_no, customer_id, product_id, order_date, order_time, delivery_date, delivery_time, order_status, total_amount, payment_status, shipping_address, quantity)
VALUES
('9876543210', 1, 1, '2025-12-01', '10:30:00', '2025-12-03', '15:00:00', 'Delivered', 250.00, 'Paid', 'Street 12, Clifton', 1),
('9123456780', 2, 2, '2025-12-02', '11:00:00', '2025-12-04', '14:00:00', 'Delivered', 120.00, 'Paid', 'House 45, Gulberg', 1),
('9234567890', 3, 3, '2025-12-03', '12:15:00', '2025-12-06', '16:00:00', 'Delivered', 200.00, 'Paid', 'Street 8, F-7/2', 1),
('9345678901', 4, 4, '2025-12-04', '09:45:00', '2025-12-07', '13:00:00', 'Delivered', 180.00, 'Paid', 'Block 3, DHA', 1),
('9456789012', 5, 5, '2025-12-05', '14:20:00', '2025-12-08', '17:30:00', 'Delivered', 300.00, 'Paid', 'Street 20, Johar Town', 1),
('9567890123', 6, 6, '2025-12-06', '10:10:00', '2025-12-09', '15:15:00', 'Delivered', 150.00, 'Paid', 'Street 10, G-10/1', 1),
('9678901234', 7, 7, '2025-12-07', '13:50:00', '2025-12-10', '16:45:00', 'Delivered', 220.00, 'Paid', 'House 25, PECHS', 1),
('9789012345', 8, 8, '2025-12-08', '11:30:00', '2025-12-11', '14:20:00', 'Delivered', 240.00, 'Paid', 'Block 6, Model Town', 1),
('9890123456', 9, 9, '2025-12-09', '15:00:00', '2025-12-12', '17:30:00', 'Delivered', 280.00, 'Paid', 'Street 5, F-8/3', 1),
('9901234567', 10, 10, '2025-12-10', '09:25:00', '2025-12-13', '12:00:00', 'Delivered', 170.00, 'Paid', 'Block 2, Korangi', 1);


create table stock(
stock_id int auto_increment primary key,
stock_name varchar(100),
quantity int,
product_id int,
supplier_name VARCHAR(100),
supplier_contact VARCHAR(50),
restock_level INT DEFAULT 10,
stock_date DATE,
last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
location VARCHAR(50),
status ENUM('In Stock','Out of Stock') DEFAULT 'In Stock',
FOREIGN KEY(product_id) REFERENCES products(product_id));

INSERT INTO stock
(stock_name, quantity, product_id, supplier_name, supplier_contact, restock_level, stock_date, location, status)
VALUES
('Silk Floral Scarf Stock', 50, 1, 'Fashion Supplies Co.', '03001234567', 10, '2025-11-25', 'Warehouse A', 'In Stock'),
('Cotton Plain Hijab Stock', 40, 2, 'Textile World', '03007654321', 10, '2025-11-25', 'Warehouse B', 'In Stock'),
('Chiffon Printed Scarf Stock', 60, 3, 'Silk & Cotton Ltd.', '03004567890', 10, '2025-11-25', 'Warehouse C', 'In Stock'),
('Wool Striped Hijab Stock', 30, 4, 'Fabric House', '03009876543', 10, '2025-11-25', 'Warehouse D', 'In Stock'),
('Georgette Floral Scarf Stock', 25, 5, 'Fashion Supplies Co.', '03001234567', 10, '2025-11-25', 'Warehouse A', 'In Stock'),
('Silk Plain Hijab Stock', 35, 6, 'Textile World', '03007654321', 10, '2025-11-25', 'Warehouse B', 'In Stock'),
('Cotton Printed Scarf Stock', 45, 7, 'Silk & Cotton Ltd.', '03004567890', 10, '2025-11-25', 'Warehouse C', 'In Stock'),
('Chiffon Striped Hijab Stock', 50, 8, 'Fabric House', '03009876543', 10, '2025-11-25', 'Warehouse D', 'In Stock'),
('Silk Floral Hijab Stock', 20, 9, 'Fashion Supplies Co.', '03001234567', 10, '2025-11-25', 'Warehouse A', 'In Stock'),
('Georgette Printed Scarf Stock', 30, 10, 'Textile World', '03007654321', 10, '2025-11-25', 'Warehouse B', 'In Stock');


create table payment (
payment_id int primary key auto_increment ,
payment_mode ENUM('Credit Card','Debit Card','UPI','Cash On Delivery'),
payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
payment_status ENUM('Pending','Completed','Failed','Refunded') DEFAULT 'Pending',
order_id int,
customer_id int,
foreign key(order_id) references orders(order_id), 
foreign key(customer_id) references customers(customer_id));

INSERT INTO payment
(payment_mode, payment_date, payment_status, order_id, customer_id)
VALUES
('Credit Card', '2025-12-01 10:35:00', 'Completed', 1, 1),
('Debit Card', '2025-12-02 11:05:00', 'Completed', 2, 2),
('UPI', '2025-12-03 12:20:00', 'Completed', 3, 3),
('Cash On Delivery', '2025-12-04 09:50:00', 'Completed', 4, 4),
('Credit Card', '2025-12-05 14:25:00', 'Completed', 5, 5),
('Debit Card', '2025-12-06 10:15:00', 'Completed', 6, 6),
('UPI', '2025-12-07 13:55:00', 'Completed', 7, 7),
('Cash On Delivery', '2025-12-08 11:35:00', 'Completed', 8, 8),
('Credit Card', '2025-12-09 15:05:00', 'Completed', 9, 9),
('Debit Card', '2025-12-10 09:30:00', 'Completed', 10, 10);


CREATE TABLE coupons (
coupon_id INT AUTO_INCREMENT PRIMARY KEY,
code VARCHAR(20) UNIQUE NOT NULL,
discount DECIMAL(5,2),
valid_from DATE,
valid_to DATE,
min_purchase_amount DECIMAL(10,2),
reminder_sent BOOLEAN);

create table festival_offers(
offer_id int AUTO_INCREMENT primary key,
offer_name varchar(100),
start_date date,
end_date date,
discount decimal(5,2),
notified boolean);



insert into festival_offers (offer_name, start_date, end_date, discount) values
('New Year Offer', '2025-12-31', '2026-01-02', 15.00),
('Valentine''s Day Offer', '2026-02-13', '2026-02-15', 10.00),
('Holi Offer', '2026-03-05', '2026-03-10', 12.00),
('Eid Offer', '2026-04-19', '2026-04-24', 20.00),
('Independence Day Offer', '2026-08-14', '2026-08-15', 10.00),
('Diwali Offer', '2026-11-01', '2026-11-07', 18.00),
('Christmas Offer', '2025-12-20', '2025-12-27', 15.00),
('Black Friday Offer', '2026-11-25', '2026-11-27', 25.00),
('Spring Festival Offer', '2026-03-21', '2026-03-25', 10.00),
('Ramadan Offer', '2026-03-01', '2026-03-30', 15.00);



create table feedback(
feedback_id int auto_increment primary key,
product_id int,
customer_id int,
rating INT CHECK (rating BETWEEN 1 AND 5),
feedback_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
feedback_status ENUM('Pending','Reviewed','Rejected') DEFAULT 'Pending',
summary text,
foreign key(product_id) references products(product_id),
FOREIGN KEY(customer_id) REFERENCES customers(customer_id));


CREATE TABLE reviews (
review_id INT AUTO_INCREMENT PRIMARY KEY,
product_id INT NOT NULL,
customer_id INT NOT NULL,
rating INT CHECK (rating BETWEEN 1 AND 5),  
review_text TEXT,                          
review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY (product_id) REFERENCES products(product_id),
FOREIGN KEY (customer_id) REFERENCES customers(customer_id));

INSERT INTO reviews (product_id, customer_id, rating, review_text) VALUES
(1, 1, 5, 'Absolutely love this silk floral scarf! Soft and elegant.'),
(2, 2, 4, 'Nice scarf but the color is slightly different than shown.'),
(3, 3, 3, 'Cotton hijab is okay, nothing special.'),
(4, 4, 4, 'Chiffon printed scarf is very stylish.'),
(5, 5, 2, 'Striped hijab did not meet my expectations.'),
(6, 6, 5, 'Silk ombre scarf is luxurious and beautiful!'),
(7, 7, 4, 'Jersey hijab is comfortable for daily wear.'),
(8, 8, 3, 'Printed viscose scarf is okay, could be better.'),
(9, 9, 5, 'Chiffon floral hijab is perfect for parties!'),
(10, 10, 4, 'Silk satin scarf feels premium and smooth.');



CREATE TABLE shipment (
shipment_id INT AUTO_INCREMENT PRIMARY KEY,
order_id INT,
shipped_date DATE,
expected_delivery DATE,
delivered_date DATE,
shipment_status ENUM('Pending','Shipped','Out for Delivery','Delivered','Cancelled') DEFAULT 'Pending',
FOREIGN KEY(order_id) REFERENCES orders(order_id));

    
    
CREATE TABLE orders_backup(
backup_id INT AUTO_INCREMENT PRIMARY KEY,
order_id INT,
order_name VARCHAR(100),
contact_no VARCHAR(15),
customer_id INT,
product_id INT,
quantity int,
order_status ENUM('Pending','Processing','Shipped','Out for Delivery','Delivered','Cancelled'),
total_amount DECIMAL(10,2),
payment_status ENUM('Pending','Paid','Failed','Refunded'),
shipping_address TEXT);


                                        TRIGGER 
                                        
                                        
delimiter ??
create trigger after_order_ins
after insert on orders
for each row
begin
update stock set quantity= quantity - new.quantity ,
status=case 
when quantity- new.quantity <=0 then 'Out of Stock'
else 'In Stock'
end
WHERE product_id =new.product_id;
end ??
delimiter ;



delimiter ??
create trigger status_stock
before insert on orders
for each row
begin
declare available_stock int ;
select quantity into available_stock from stock where product_id =new.product_id;
if available_stock is null or available_stock <new.quantity 
then signal sqlstate '45000'
set message_text = 'Out of stock';
end if;
end ??
delimiter ;




delimiter ??
create trigger payment_update
after update on payment
for each row
begin
if new.payment_status = 'Completed' then
 update orders set payment_status="Paid",
 order_status="Processing" 
 where order_id=new.order_id;
 end if;
 end ??
delimiter ;



delimiter ??
create trigger ins_backup
after insert on orders
for each row
begin
insert into orders_backup(order_id , customer_id,contact_no ,product_id ,quantity ,order_status ,
total_amount ,payment_status ,shipping_address) VALUES(new.order_id ,new.customer_id,new.contact_no ,new.product_id ,new.quantity ,
new.order_status ,new.total_amount ,new.payment_status ,new.shipping_address);
end ??
delimiter ;



delimiter ??
create trigger restock_product_on_cancel
after update on orders
for each row 
begin
if old.order_status = 'Cancelled' and new.order_status='Cancelled'
then update stock set quantity=quantity + old.quantity
where product_id=old.product_id ;
end if;
end ??
delimiter ;




delimiter ??
create trigger membership_offer
after insert on orders
for each row
begin
    declare cust_membership varchar(20);
    declare discount_factor decimal(4,2);

    select membership_status into cust_membership 
    from customers 
    where customer_id = new.customer_id;

    if cust_membership = 'Silver' then
        set discount_factor = 0.85;  
    elseif cust_membership = 'Gold' then
        set discount_factor = 0.80;  
    elseif cust_membership = 'Platinum' then
        set discount_factor = 0.75; 
    else
        set discount_factor = 1;     
    end if;
    update orders 
    set total_amount = total_amount * discount_factor
    where order_id = new.order_id;
end??
delimiter ;




delimiter ??
create trigger prevent_cancel_after_delivery
before update on orders
for each row
begin
if new.order_status= 'Cancelled'
then if old.order_status='Delivered'
then signal sqlstate'45000'
set message_text='Cannot cancel the order. It has already been delivered.';
end if;
end //
delimiter ;


delimiter ??
create trigger no_return_if_damaged
before update on orders
for each row
begin
if new.order_status='Returned'
then if old.damaged = 'Yes'
then SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Cannot return the order. It is damaged.';
end if;
end //
delimiter ;


                                   EVENTS
                                   
                                   
delimiter  ??
CREATE EVENT notify_expiring_coupons
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    UPDATE coupons
    SET reminder_sent = TRUE
    WHERE DATEDIFF(valid_to, CURDATE()) = 2
    AND reminder_sent = FALSE;

    SELECT code, valid_to, discount 
    FROM coupons
    WHERE DATEDIFF(valid_to, CURDATE()) = 2;
END ??
DELIMITER ;



DELIMITER $$
CREATE EVENT check_return_eligibility
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    UPDATE orders
    SET return_eligible = 'No'
    WHERE order_status = 'Delivered'
      AND DATEDIFF(CURDATE(), delivery_date) > 5
      AND return_eligible = 'Yes';
END $$
DELIMITER ;


DELIMITER $$
CREATE EVENT notify_festival_offers
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    UPDATE festival_offers
    SET notified = TRUE
    WHERE start_date = CURDATE() AND notified = FALSE;

    SELECT offer_name, start_date, end_date, discount
    FROM festival_offers
    WHERE start_date = CURDATE();
END $$
DELIMITER ;



                             STORED PROCEDURE

delimiter ??
create procedure product_order_history ( in p_product_id int)
begin
select p.product_name, o.order_id, o.quantity, o.order_status ,o.order_date , o.total_amount from orders o
 inner join products p on o.product_id=p.product_id where o.product_id = p_product_id order by o.order_date desc;
 end ??
 delimiter ;
 
call product_order_history (1);




delimiter //
create procedure product_monthly_revenue(in p_product_id int, in p_product_name varchar(100))
begin
select month(o.order_date) as month , year(o.order_date) as year ,
sum(o.total_amount) astotal_revenue,
sum(o.total_amount -(p.amount*o.quantity))as profit_or_loss,
sum(o.quantity) as total_sold from orders o inner join products p ON o.product_id = p.product_id
where (o.product_id = p_product_id or p.product_name = p_product_name)
group by year (o.order_date), month(o.order_date)
order by year(o.order_date), month(o.order_date);
end //
delimiter ;






delimiter //
create procedure get_product_reviews(in p_product_id int)
begin
select p.product_name,count(r.review_id)as total_reviews from reviews r inner join products p on
r.product_id=p.product_id where r.product_id = p_product_id group by r.product_id;

SELECT c.first_name,c.last_name,r.review_id,r.rating,r.review_text,r.review_date from reviews r
inner join customers c on r.customer_id = c.customer_id where r.product_id = p_product_id order by r.review_date DESC;
END //
delimiter ;





delimiter //
create procedure customer_purchase_history(in p_customer_id int)
begin
select p.product_name,o.order_id,o.quantity,o.order_date,o.order_status,o.total_amount from orders o
inner join products p on o.product_id = p.product_id where  o.customer_id = p_customer_id order by o.order_date desc;
end //
delimiter ;

call customer_purchase_history(3);







delimiter //
create procedure top_selling_products(in p_month int,in p_year int)
begin
select p.product_name,sum(o.quantity) as total_units_sold,
sum(o.total_amount)as total_revenue from orders o inner join  products p on o.product_id = p.product_id where
 month (o.order_date)=p_month and year(o.order_date) = p_year group by p.product_id, p.product_name order by
 total_units_sold desc;
end //
delimiter ;

                                         FUNCTION
                                         

delimiter //
create function get_discounted_price(p_price decimal(10,2), p_discount decimal(5,2))
returns decimal(10,2)
deterministic
begin
return p_price- (p_price * p_discount /100);
end //
delimiter ;




delimiter //
create function can_return(delivery_date date)
returns enum('Yes','No')
deterministic
begin
if datediff(curdate(),delivery_date) <= 5 
then return'Yes';
else
return 'No';
end if;
end //
delimiter ;